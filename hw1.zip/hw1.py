# Imports
import time
from contextlib import closing
from socket import socket, AF_INET, SOCK_DGRAM
import struct
import tkinter as tk

# Given Constants
NTP_PACKET_FORMAT = "!12I"
NTP_DELTA = 2208988800  # 1970-01-01 00:00:00
NTP_QUERY = '\x1b' + 47 * '\0'


# Will time out if it does not recieve a response in 5 seconds.
def ntp_time(host):
    port = 123
    with closing(socket(AF_INET, SOCK_DGRAM)) as s:
        try:
            s.settimeout(5)
            s.sendto(NTP_QUERY.encode('utf-8'), (host, port))
            msg, address = s.recvfrom(1024)

            unpacked = struct.unpack(NTP_PACKET_FORMAT, msg[0:struct.calcsize(NTP_PACKET_FORMAT)])
            return abs(time.time() - (unpacked[10] + float(unpacked[11]) / 2 ** 32 - NTP_DELTA))
        except:
            return 0


# Template code followed from
# https://stackoverflow.com/questions/35666573/use-tkinter-to-draw-a-specific-bar-chart
def graph_discrepancy(time_list, server_list):
    data = time_list

    root = tk.Tk()
    root.title("Time Server Latency")

    # Setting up the screen
    c_width = 1200  # Define it's width
    c_height = 1050  # Define it's height
    c = tk.Canvas(root, width=c_width, height=c_height, bg='white')
    c.pack()

    y_gap = 80  # The gap between lower canvas edge and x axis
    x_stretch = 10  # Stretch x wide enough to fit the variables
    
    
    y_stretch = c_height * 1 / time_list[time_list.index(max(time_list))] * 4 / 5
    x_width = c_width / (len(time_list) * 3 / 2)  # The width of the x-axis
    x_gap = (c_width - (x_width * len(time_list))) / (len(time_list))  # The gap between left canvas edge and y axis
    
    # A quick for loop to calculate the rectangle
    for x, y in enumerate(data):

        # Bottom left coordinate
        x0 = x * x_stretch + x * x_width + x_gap

        # Top left coordinates
        y0 = c_height - (y * y_stretch + y_gap)

        # Bottom right coordinates
        x1 = x * x_stretch + x * x_width + x_width + x_gap

        # Top right coordinates
        y1 = c_height - y_gap

        # Drawing the legend, server name, and server value
        c.create_text(x0 - 2, y1 + 15, anchor=tk.SW, text=str(x))
        c.create_text(x_width, 15 + x * 20, anchor=tk.SW, text=(str(x) + ' = ' + str(server_list[x])))
        c.create_text(x0 + 2, y0, anchor=tk.SW, text=str('%.3f' % y))

        # Draw the bar
        if 1 > y:
            c.create_rectangle(x0, y0, x1, y1, fill="green")
        else:
            c.create_rectangle(x0, y0, x1, y1, fill="red")
    root.mainloop()


if __name__ == "__main__":
    time_list = []

    with open('input.txt') as f:
        server_list = f.read().splitlines()

    if len(server_list) > 0:
        for i in server_list:
            tmp = (ntp_time(i))
            time_list.append(tmp)

        print('Largest discrepancy')
        print(server_list[time_list.index(max(time_list))])
        print(time_list[time_list.index(max(time_list))])

        graph_discrepancy(time_list, server_list)
    else:
        print('Need at least one server to run')
